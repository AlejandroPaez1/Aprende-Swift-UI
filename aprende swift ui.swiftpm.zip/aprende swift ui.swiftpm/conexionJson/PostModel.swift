//
//  File.swift
//  
//
//  Created by ADMIN UNACH on 21/04/23.
//

import Foundation

struct PostModel: Decodable{
    var token = String()
}
