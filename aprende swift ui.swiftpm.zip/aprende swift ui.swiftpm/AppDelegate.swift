//
//  AppDelegate.swift
//  aprende swift ui
//
//  Created by ADMIN UNACH on 18/04/23.
//

import UIKit
class appDelegate: NSObject,UIApplicationDelegate{
}
    
