//
//  vista2tabView.swift
//  aprende swift ui
//
//  Created by ADMIN UNACH on 18/04/23.
//

import SwiftUI

struct vista2tabView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct vista2tabView_Previews: PreviewProvider {
    static var previews: some View {
        vista2tabView()
    }
}
